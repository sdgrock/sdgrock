﻿using System;
using System.IO;

namespace MyFile
{
    public class FileDemo
    {
        static void Main(string[] args)
        {
            try
            {
                FileInfo Obj = new FileInfo(@"d:\capgemini.txt");
                if (Obj.Exists)
                {
                    Console.WriteLine("File_Name = {0}", Obj.Name);
                    Console.WriteLine("File length in Bytes = {0}", Obj.Length);
                    Console.WriteLine("File Extension = {0}", Obj.Extension);
                    Console.WriteLine("File Full path = {0}", Obj.FullName);
                    Console.WriteLine("File Directory = {0}", Obj.DirectoryName);
                    Console.WriteLine("File Parent Directory = {0}", Obj.Directory);
                    Console.WriteLine("File Creation Date and Time = {0}", Obj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Modified Date and Time = {0}", Obj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Last Access Date and Time = {0}", Obj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Attributes = {0}", Obj.Attributes.ToString());
                }
                else
                {
                    Console.WriteLine("File does not exist");
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
