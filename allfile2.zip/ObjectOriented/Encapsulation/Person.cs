﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Encapsulation
{
    public class CPerson
    {
        #region Field

        int _aadharid;
        string _name;
        byte _age;
        int _month;
 

        #endregion

        #region Property
      

        public int AADHARID 
        { 
            get{ return _aadharid; }
            set{ _aadharid=value; } 
        }

        public string NAME
        {
            get{ return _name; }
            set { _name=value; }
        }

        public byte AGE
        {
            get { return _age; }
            set { _age=value; }
        }
        
        public int MONTH
        {
            get { return _month; }
            set
            {
                if ((value > 0) && (value < 13))
                {
                    _month = value;
                  
                }
                
                else
                {
                    Console.WriteLine("Error");
                }

            }
        }
        public string EMAILID
        {
            get;
            set;

        }
        #endregion

        #region Method

        [Obsolete("This method is not available in the next version of library")]

        #endregion

        public void mage(out int age)
        {
            age = 100;
            Console.WriteLine("age is {0}",_age);
        }

        public static void mSwap(ref int num1, ref int num2)
        {
            //int temp;
            //temp = num1;
            //num1 = num2;
            //num2 = temp;

            num1 = num1 + num2;
            num2 = num1 - num2;
            num1 = num1 - num2;
        }

        public static int Sum(params int[] Param1)
        {
            int val = 0;
            foreach (int P in Param1)
            {
                val = val + P;
            }
            return val;
        }

        #region Constructor

        public CPerson()
        {

        }


        public CPerson(int aadharid, string name, byte age)
        {
            this._aadharid = aadharid;
            this._age = age;
            this._name = name;
        }
        #endregion
    }
}
