﻿using System;
using Encapsulation;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int newage = 30;
            int newnum1 = 30;
            int newnum2 = 40;
            CPerson persobj = new CPerson();
            CPerson persobj1 = new CPerson(231, "Ram", 20);
            persobj1.AADHARID = 233;
            Console.WriteLine(persobj1.AADHARID);
            Console.WriteLine(persobj1.NAME);
            Console.WriteLine(persobj1.AGE);
            persobj1.mage(out newage);
            Console.WriteLine("The vaue of newage is " +newage);
            Console.WriteLine("Values before swap are num1{0}, num2{1}", newnum1, newnum2);
            CPerson.mSwap(num2:ref newnum2, num1:ref newnum1);
            Console.WriteLine("Values after swap are num1{0}, num2{1}", newnum1, newnum2);
            persobj1.EMAILID = Console.ReadLine();
            Console.WriteLine(persobj1.EMAILID);
            Console.WriteLine(CPerson.Sum(1, 2, 3));
            Console.WriteLine(CPerson.Sum(1, 2, 3, 4, 5));
            persobj1.MONTH = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine(persobj1.MONTH);
            System.Console.Read();
        }
    }
}
