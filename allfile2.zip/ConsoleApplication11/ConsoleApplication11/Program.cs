﻿using System;
using System.Data;
using System.Data.SqlClient;
namespace ConsoleApplication11
{
    class Program
    {
        static SqlConnection con = null; //object for connection
        static SqlCommand com = null; //object for command


        static void Main(string[] args)
        {
            //SqlDataReader
            con = new SqlConnection(
                "Data Source=.;Initial Catalog=master;Integrated Security=True");

            try
            {
                con.Open();
                Console.WriteLine("Connected Succesfully...");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "Select EmployeeID from Employees";
            com.CommandType = CommandType.Text;
            Console.ReadLine();
        }
    }
}
