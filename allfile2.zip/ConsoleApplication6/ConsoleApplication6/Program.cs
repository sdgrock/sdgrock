﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Emp : IComparable<Emp>
    {
        public string Ename { get; set; }
        public int Salary { get; set; }


        public int CompareTo(Emp other)
        {
            //throw new NotImplementedException();
            if (this.Salary > other.Salary)
                return -1;
            else if (this.Salary < other.Salary)
                return 1;
            else
                return 0;
        }
    }

    public class MyStack<T>: Stack<T>{}
    class Program
    {
        static void Main(string[] args)
        {
            List<Emp> emp = new List<Emp>()
            {
            new Emp { Ename = "E1", Salary = 12345 },
            new Emp { Ename = "E2", Salary = 19955 },
            new Emp { Ename = "E3", Salary = 52455 }
            };

            emp.Sort();
            foreach (Emp e in emp)
            {
                Console.WriteLine(e.Ename + " " + e.Salary);
            }
        }
    }
}
