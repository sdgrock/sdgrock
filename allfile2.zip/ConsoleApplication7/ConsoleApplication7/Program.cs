﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyMathLib;

namespace ConsoleApplication7
{ 
    delegate int mathdelegate(params int[] array);

    class Program
    {
        public void Main(string[] args)
        {
            MyMath obj = new MyMath();
            Console.WriteLine(obj.DoSum(4, 5, 6, 7, 8));
            mathdelegate del = obj.DoSum;
            Console.WriteLine(del(4, 5, 6, 7, 8));
        }
    }
}
