﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication10
{

    enum callType {Audio, Video}
    class CallEventArgs : EventArgs
    {
        public callType callType;

        public CallEventArgs()
        {
            Random r = new Random();
            callType = r.Next() % 2 == 0 ?
                callType.Audio : callType.Video;
        }
    }

    class Mobile
    {
        public string MobileName { get; set; }
        public delegate void CallEvent(object o, CallEventArgs ce);
        public event CallEvent CallRings;

        public Mobile(string mobileName)
        {
            MobileName = mobileName;
        }

        public void OnCallRing()
        {
            if (CallRings != null)
            {
                CallRings(this, new CallEventArgs());
            }
        }
    }

    class DemoEventArgs
    {
        static void Main(string[] args)
        {
            Mobile SamsungMobile = new Mobile("Samsung Note 8");
            Mobile IPhoneMobile = new Mobile("IPhone 8");
            SamsungMobile.CallRings += MyMobileRings;
            IPhoneMobile.CallRings += MyMobileRings;
            SamsungMobile.OnCallRing();
            IPhoneMobile.OnCallRing();
            Console.ReadLine();
        }

        public static void MyMobileRings(Object o, CallEventArgs ce)
        {
            Console.WriteLine("My {0} mobile gets a {1} call...",((Mobile)o).MobileName, ce.callType) ;
        }
    }
}
