﻿namespace ConsoleApplication3
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    [System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = true)]

    public class Author : Attribute
    {
        string name;


        public Author(string name)
        {
            this.name = name;
        }

        public string GetName()
        {
            return name;
        }
    }
}