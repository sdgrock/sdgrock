﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
  public class Refexample
  {
    // Class with multiple Author attributes.  
    [Author("P. Ackerman"), Author("R. Koch"), Author("R. L. Stevenson")]
    public class AuthorClass
    {
        // ...  
    }

        static void Main(string[] args)
        {
          
            PrintAuthorInfo(typeof(AuthorClass));
        }

        private static void PrintAuthorInfo(System.Type t)
        {
            System.Console.WriteLine("Author information for {0}", t);

            // Using reflection.  
            System.Attribute[] attrs = System.Attribute.GetCustomAttributes(t);  // Reflection.  

            // Displaying output.  
            foreach (System.Attribute objattr in attrs)
            {
                if (objattr is Author)
                {
                    Author obj = (Author)objattr;
                    System.Console.WriteLine("  {0}", obj.GetName());
                }
            }
        }
    }  

}


}
