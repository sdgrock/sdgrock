﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    public class MyStack<T>:Stack<T>{}
    class Program
    {
        public static void Main(string[] args)
        {
            Stack<string> cities = new MyStack<string>();
            cities.Push("Delhi");
            cities.Push("Mumbai");
            cities.Push("Chennai");
            cities.Push("Bangalore");
            cities.Push("Kolkata");

            foreach (string s in cities)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine(cities.Contains("Mumbai"));
            Console.WriteLine(cities.Count);
            Console.ReadLine();
        }
    }
}
