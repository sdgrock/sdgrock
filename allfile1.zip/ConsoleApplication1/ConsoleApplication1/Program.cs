﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using csharpfirstlib;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(CSharpFirstClass.madd(100, 200));
            Console.WriteLine("My First Example in C#");
            Console.WriteLine("Hello World");
            System.Console.ReadKey();

        }
    }
}
