﻿Imports BankBEntities

Module Module1

    Sub Main()
        Dim accentobj As New CAccountsEnt
        Dim svcobj As New CSavingAccounts(accentobj)
        svcobj.
    End Sub

End Module
