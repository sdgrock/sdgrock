﻿
Class CSavingAccounts

    Private _accentobj As CAccountsEnt

    Sub New(accentobj As CAccountsEnt)
        ' TODO: Complete member initialization 
        _accentobj = accentobj
    End Sub

End Class
