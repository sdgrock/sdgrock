﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExceptionApplicant;
using BALApplicant;
using EntApplicant;


namespace Applicant
{
  
    class PresentationApplicant
    {
        
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddData();
                        break;
                    case 2:
                        SearchApplicantBL();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

        private static void SearchApplicantBL()
        {
            throw new NotImplementedException();
        }

        private static void AddData()
        {
            throw new NotImplementedException();
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n*********Applicant Details*********");
            Console.WriteLine("1. Add Training");
            Console.WriteLine("2. Search Applicant");
            Console.WriteLine("3. Exit");
            Console.WriteLine("***********************************\n");
        }

        private static void AddTraining()
        {
            try
            {
                Console.WriteLine("Enter Name :");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Address :");
                string addr = Console.ReadLine();
                Console.WriteLine("Enter City :");
                string city = Console.ReadLine();
                Console.WriteLine("Enter Designation :");
                string designation = Console.ReadLine();
                Console.WriteLine("Enter Qualification(A for BE/B for ME/C for MCA)");
                char qual = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("Enter Mobile :");
                string mob = Console.ReadLine();
                EntityApplicant applicant = new EntityApplicant(name, qual, mob, addr, city);

                bool dataadded = BusinessApplicant.AddData(applicant);
                if (Dataadded)
                    Console.WriteLine("Data Added");
                else
                    Console.WriteLine("Data not Added");
            }
            catch (ExcepApplicant ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        
    }
}
