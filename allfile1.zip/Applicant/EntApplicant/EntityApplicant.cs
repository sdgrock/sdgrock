﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntApplicant
{
    public enum Qualification { BE, ME, MCA }
    public enum City { Mumbai, Pune, Chennai, Bangalore }
    public enum Designation { Manager, DeputyManager, AssistantManager }
    public enum MaritalStatus { Married, Unmarried }

    public class EntityApplicant
    {
        #region Fields
        private string _name;
        private int _qualification;
        private int _mobile;
        private string _address;
        private int _city;
        private int _designation;
        private int _dob;
        private int _maritalStatus;
        
        #endregion

        #region Property
        public string NAME { get { return _name; } set { _name = value; } }

        public int QUALIFICATION
        {
            get { return _qualification; }
            set
            {
                if (value == 'A')
                    _qualification = (int)Qualification.BE;
                if (value == 'B')
                    _qualification = (int)Qualification.ME;
                if (value == 'C')
                    _qualification = (int)Qualification.MCA;
            }
        }

        public int MOBILE { get { return _mobile; } set { _mobile = value; } }
 
        public string ADDRESS { get { return _address; } set { _address = value; } }

        public int CITY
        {
            get { return _city; }
            set
            {
                if (value == 'M')
                    _city = (int)City.Mumbai;
                if (value == 'P')
                    _city = (int)City.Pune;
                if (value == 'C')
                    _city = (int)City.Chennai;
                if (value == 'B')
                    _city = (int)City.Bangalore;
            }
        }

        public int DESIGNATION
        {
            get { return _designation; }
            set
            {
                if (value == 'M')
                    _designation = (int)Designation.Manager;
                if (value == 'D')
                    _qualification = (int)Designation.DeputyManager;
                if (value == 'A')
                    _qualification = (int)Designation.AssistantManager;
            }
        }

        public int DOB { get { return _dob; } set { _dob = value; } }

        public int MARITALSTATUS
        {
            get { return _maritalStatus; }
            set
            {
                if (value == 'M')
                    _maritalStatus = (int)MaritalStatus.Married;
                if (value == 'U')
                    _maritalStatus = (int)MaritalStatus.Unmarried;
            }
        }
    
        #endregion

        #region Constructor
        public EntityApplicant()
        {

        }

        public EntityApplicant(string name, char qual, int mob, string addr, char city,int dob,char ms )
        {
            NAME = name;
            QUALIFICATION = qual;
            MOBILE = mob;
            ADDRESS = addr;
            CITY = city;
            DOB = dob;
            MARITALSTATUS = ms;
        }

         #endregion

        #region Method
        #endregion


        public bool addapplicantDAL(EntityApplicant applicant)
        {
            throw new NotImplementedException();
        }

        public EntityApplicant SearchApplicantDAL(int searchApplicantData)
        {
            throw new NotImplementedException();
        }
    }
}
    