﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionApplicant
{
    public class ExcepApplicant : ApplicationException
    {
       #region Constructor
       public ExcepApplicant() : base()
        {

        }
        public ExcepApplicant(string message):base(message)
        {
            Console.WriteLine(message);
        }
        public ExcepApplicant(string message,Exception innerexception):base(message,innerexception)
        {
            Console.WriteLine(message);
        }
        #endregion
    }
}
