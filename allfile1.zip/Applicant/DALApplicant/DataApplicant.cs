﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExceptionApplicant;
using EntApplicant;

namespace DALApplicant
{
    public class DataApplicant
    {
        static List<EntityApplicant> listobj = new List<EntityApplicant>();

        public bool addapplicantDAL(EntityApplicant applicant)
        {
            bool Dataadded = false;
            try
            {
                listobj.Add(applicant);
                Dataadded = true;
            }
            catch (Exception e)
            {
                //Console.WriteLine("herllo");
               // throw new ExcepApplicant(e.Message);
            }
            return Dataadded;
        }

        public EntityApplicant SearchApplicantDAL(string nam)
        {
            EntityApplicant searchapplicant = null;
            try
            {
                foreach (var item in listobj)
                {
                    if (item.NAME == nam )
                    {
                        searchapplicant = item;
                    }
                }
            }
            catch (Exception e)
            {
                //throw new EntityApplicant(e.Message);
            }
            return searchapplicant;
        }
    }
}
