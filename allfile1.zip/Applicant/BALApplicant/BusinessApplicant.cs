﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntApplicant;
using ExceptionApplicant;

namespace BALApplicant
{
    public class BusinessApplicant
    {
        private static bool ValidateApplicant(EntityApplicant applicant)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (applicant.ADDRESS == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Invalid Address");
            }

            if (applicant.NAME == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Name not found");
            }

            if (valid == false)
            {
                //throw new ExcepApplicant(sb.ToString());
            }
            return valid;
        }
        public static bool AddData(EntityApplicant applicant)
        {
            bool Dataadded = false;
            try
            {
                if (ValidateApplicant(applicant))
                {
                    EntityApplicant dal = new EntityApplicant();
                    Dataadded = dal.addapplicantDAL(applicant);
                }
            }
            catch (ExcepApplicant)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Dataadded;
        }

        public static EntityApplicant SearchApplicantBL(int searchApplicantData)
        {
            EntityApplicant searchApplicant = null;
            try
            {
                EntityApplicant guestDAL = new EntityApplicant();
                searchApplicant = guestDAL.SearchApplicantDAL(searchApplicantData);
            }
            catch (ExcepApplicant ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchApplicant;

        }
    }
}
