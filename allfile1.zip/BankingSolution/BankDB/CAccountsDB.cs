﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankDB
{
    public class CAccountsDB
    {
        #region Field
        #endregion

        #region Property
        #endregion

        #region Methods
        #endregion

        #region Constructor
        #endregion

    }
}
