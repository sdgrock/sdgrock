﻿using System;
using BankBEntities;
using BankClassLib;
using System.Collections.Generic;
 

namespace BankConsoleUI
{
    class Program
    {
        static void EmailAlert(CAccountsEnt entobj)
        {
            Console.WriteLine("Your Balance has been changed");
        }
        static void Main(string[] args)
        {
            List<CAccountsEnt> listobj = new List<CAccountsEnt>();
            CAccountsEnt[] accentobj = new CAccountsEnt[1];
            for (int counter = 0; counter < accentobj.Length; counter++)
            {
                accentobj[counter] = new CAccountsEnt();
            }
                for (int counter = 0; counter < accentobj.Length; counter++)
                {
                    Console.WriteLine("Enter Account Number");
                    accentobj[counter].ACCOUNTNO = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Account Holder's Name");
                    accentobj[counter].ACC_HOLD_NAME = Console.ReadLine();
                    Console.WriteLine("Enter Account Type");
                    accentobj[counter].ACC_TYPE = Console.ReadLine();
                    Console.WriteLine("Enter Transaction Type");
                    accentobj[counter].TRANS_TYPE = Console.ReadLine();
                    Console.WriteLine("Enter Amount");
                    accentobj[counter].AMOUNT = Convert.ToDecimal(Console.ReadLine());
                }
            listobj.AddRange(accentobj);
            foreach(var item in listobj)
            {
                Console.WriteLine("Account No is {0} ", item.ACCOUNTNO);
                Console.WriteLine("Account Name is {0} ", item.ACC_HOLD_NAME);
                Console.WriteLine("Account Type is {0} ", item.ACC_TYPE);
                Console.WriteLine("Transaction  Type is {0} ", item.TRANS_TYPE);
                Console.WriteLine("Amount is {0} ", item.AMOUNT);
               // Console.WriteLine("Balance is {0} ", item.BALANCE);
            }

            CSavingAccounts accobj = new CSavingAccounts(accentobj[0]);
            accobj.onbalchange += new OnBalancechange(EmailAlert);
            Console.WriteLine(accobj.BALANCE);
             Console.WriteLine("Enter the amount to withdraw");
            accentobj[0].AMOUNT = decimal.Parse(Console.ReadLine());
            try
            {
                accobj.mWithdraw(accentobj[0]);
            }
            catch (InsufficientFundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            Console.WriteLine(accobj.BALANCE);
        }
    }
}
