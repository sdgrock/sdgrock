﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankClassLib
{   [AttributeUsage(AttributeTargets.Property|AttributeTargets.Method,AllowMultiple=true)]
    class ValidateName:Attribute
    {

        #region field

        string _message;

        #endregion
        #region property

        public string Message { get { return _message; }
            set { _message = value; }
        }


        #endregion
        public bool IsValid(string name)
        {
            bool flag = false;
            string myname = name;
            if (myname == name.ToUpper())
            {
                flag = true;

            }
            else
            {
                flag = false;
            }

            return flag;
        }


    }
}
