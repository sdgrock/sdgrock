﻿using System;
using BankBEntities;

namespace BankClassLib
{
    public delegate void OnBalancechange(CAccountsEnt entobj);

    public class CSavingAccounts:CAccounts, ICalcInterest
    {
        #region Field
        private decimal _balance;
        public event OnBalancechange onbalchange;
        OnBalancechange balchange = new OnBalancechange(SMSAlert);
        #endregion

        #region property
        public decimal BALANCE{ get { return _balance; } }
        #endregion

        #region Method
        public override void mDeposit(CAccountsEnt accobj)
        { 
            _balance+=accobj.AMOUNT;
            balchange(accobj);
            if(onbalchange!=null)
            {
                onbalchange(accobj);
            }
        }

        public override void mWithdraw(CAccountsEnt accobj)
        {
            if (_balance > 5000)
            {
                _balance -= accobj.AMOUNT;
                balchange(accobj);
                if (onbalchange != null)
                {
                    onbalchange(accobj);
                }
            }
            else
            {
                throw new InsufficientFundException("You have Insuffient Funds");
            }
          //  _balance-=_balance;
        }

        public decimal interestcalc(int time, float rate, decimal amt)
        {
            return ((decimal)time * (decimal)rate * amt);
        }

        public static void SMSAlert(CAccountsEnt accentobj)
        {
            Console.WriteLine("SMS Alert");
            Console.WriteLine("Account No {0} has changed in balance", accentobj.ACCOUNTNO);
        }


        #endregion

        #region Constructor

        public CSavingAccounts(CAccountsEnt entobj)
        {
            _balance = entobj.AMOUNT;
        }
       

        #endregion

        
    }
}
