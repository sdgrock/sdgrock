﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayListEx
{
    delegate int calculate(int num1, int num2);


    class DelegateEx
    {
        public static int add(int mynum1, int mynum2)
        {
            Console.WriteLine(mynum1 + mynum2);
            return mynum1 + mynum2;
        }

        public static int subtract(int mynum1, int mynum2)
        {
            Console.WriteLine(mynum1 - mynum2);
            return mynum1 - mynum2;
        }

        public static int multiply(int mynum1, int mynum2)
        {
            Console.WriteLine(mynum1 * mynum2);
            return mynum1 * mynum2;
        }

        public static float divide(int mynum1, int mynum2)
        {
            Console.WriteLine((float)mynum1 / mynum2);
            return (float)mynum1 / mynum2;
        }

        static void Main(string[] args)
        {
            calculate calcobj = new calculate(add);
            calcobj += new calculate(subtract);
            calcobj += new calculate(multiply);
            Console.WriteLine(calcobj.Invoke(10, 20));
            calcobj -= new calculate(multiply);
            Console.WriteLine(calcobj.Invoke(30, 20));
        }
    }
}

