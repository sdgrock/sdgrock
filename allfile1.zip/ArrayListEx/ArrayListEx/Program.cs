﻿using System;
using System.Collections;


namespace ArrayListEx
{
    public class SamplesArrayList
    {
        public static void Main()
        {
            //Create and initializes a new ArrayList.
            ArrayList myAL = new ArrayList();
            myAL.Add("One");
            myAL.Add("Two");
            myAL.Add("!");
            myAL.Add(20);
            //Displays the properties and values of the ArrayList.
            Console.WriteLine("\tCount:  {0}", myAL.Count);
            Console.WriteLine("\tCapacity:  {0}", myAL.Capacity);
            Console.WriteLine("\tValues:");
            //PrintValues(myAL);

            foreach (var item in PrintValues(myAL))
            {
                Console.WriteLine(item.ToString());
            }
            Console.Read();   
        }

        public static IEnumerable PrintValues(ArrayList myList)
        {
            foreach (var item in myList)
            {
                yield return item;
            }
        }


        public static void PrintValues(IEnumerable myList)
        {
            IEnumerator myEnumerator = myList.GetEnumerator();
           /* while(myEnumerator.MoveNext())
            {
                Console.Write("\t{0}", myEnumerator.Current);
            }
            Console.WriteLine();*/
        }

    }
}
