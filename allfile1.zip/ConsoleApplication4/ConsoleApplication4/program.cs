﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

AttributeUsage(AttributeTargets.Class,AllowMultiple = true)

namespace ConsoleApplication4
{
    
    class AuthorAttribute : Attribute
    {
        string _author;

        public string AuthorName
        {
            get
            {
                return _author;
            }
        }
    }
    [Author("abc")]
    [Author("xyz")]
    class student
    {
        static void Main(string[] args)
        {
            Type type=typeof(student);
            object[] attributes = type.GetCustomAttributes(typeof(student), false);

            foreach(object o in attributes)
            {
                Console.WriteLine((AuthorAttribute)o).AuthorName
            }
        }
    }
}
