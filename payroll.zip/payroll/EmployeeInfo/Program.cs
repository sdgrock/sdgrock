﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpEnt;
using EmpUtility;
using System.Reflection;
using EmployeeInfo;
using EmpBAL;


namespace EmployeeInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            EmpBEntity emp = new EmpBEntity();
           
            Console.Write("Enter Employee ID:");
            emp.EmpID = int.Parse(Console.ReadLine());


            Console.Write("Enter Employee Name:");
            emp.EmpName = Console.ReadLine();

            Console.Write("Enter Basic:");
            emp.BASIC = decimal.Parse(Console.ReadLine());
           

            Console.WriteLine("EMPLOYEE id {0}", emp.EmpID);
            Console.WriteLine("EMPLOYEE name {0}", emp.EmpName);
            Console.WriteLine("EMPLOYEE Basic {0}", emp.BASIC);
            Console.WriteLine("EMPLOYEE Gross Salary {0}", emp.GROSS);
            Console.WriteLine("EMPLOYEE Net Salary {0}", emp.NET);
            Console.ReadKey();
        }


        private static bool ValidateEmployee(EmpBEntity employee)
        {
            PropertyInfo[] properties = employee.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo property in properties)
            {
                object[] customAtt = property.GetCustomAttributes(typeof(IAttribute), true);

                foreach (object att in customAtt)
                {
                    IAttribute valAtt = (IAttribute)att;
                    if (valAtt == null) continue;

                    if (valAtt.IsValid(property.GetValue(employee, null))) continue;
                    ErrorMessage error = new ErrorMessage(property.Name, valAtt.Message);
                    employee.ErrorList.Add(error);

                }

            }

            return (employee.ErrorList.Count == 0);

        }


    }
}
