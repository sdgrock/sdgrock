﻿using System;
using EmpUtility;
namespace EmpEnt
{
    public class EmpBEntity:AttributeErrors
    {
        #region Field
        private int _empid;
        private string _empname;
        private decimal _basic;
        private decimal _hra;
        private decimal _da;
        private decimal _pf;
        private decimal _gross;
        private decimal _net;
        #endregion

        #region Property
        public decimal HRA { get { return _hra; } set {; } }

        public decimal DA { get { return _da; } set {; } }


        public decimal PF { get { return _pf; } set {; } }

        public decimal GROSS { get { return _gross; } set {; } }


        public decimal NET { get { return _net; } }
        public int EmpID { get { return _empid; } set { _empid = value; } }
        public string EmpName { get { return _empname; } set { _empname = value; } }


        [CheckRange(100000,10000,"Basic Salary Can be between 10000 and 100000")]
        public decimal BASIC { get { return _basic; } set { _basic = value; } }
      


        #endregion

        #region Method
        #endregion

        #region Constructor

        public EmpBEntity()
        {

        }

        public EmpBEntity(int empid,string empname,decimal basic)
        {
            this._empname = empname;
            this._empid = empid;
            this._basic = basic;
        }

        #endregion
    }
}
