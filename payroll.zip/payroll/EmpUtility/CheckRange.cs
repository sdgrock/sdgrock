﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpUtility
{
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple = true)]
    public class CheckRange : Attribute, IAttribute
    {
     
        string errormessage;
      
        #region IAttribute Members

        int maxval, minval;
        public CheckRange(int maxval, int minval, string errmsg)
        {
            this.maxval = maxval;
            this.minval = minval;
            _errormessage = errmsg;
        }
        string _errormessage;
        public string Message
        {
            get
            {
                return _errormessage;
            }
            set
            {
                _errormessage = value;
            }
        }

        public bool IsValid(object item)
        {
            bool flag = false;
            decimal basval = (decimal)item;
            if (basval < maxval && basval > minval)
            {
                flag = true;
            }
            return flag;


            #endregion



        }
    }
}
