﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpEnt;
namespace EmpBAL
{
    public class EmpInfoBAL
    {

        #region Field

        #endregion

        #region Property

      


        #endregion

        #region Method

        public void mCalcGross(EmpBEntity entobj)
        {
            entobj.HRA =(entobj.BASIC) *(decimal) 0.30;
            entobj.DA = (entobj.BASIC) * (decimal)0.40;
            entobj.GROSS = (entobj.BASIC) + entobj.HRA + entobj.DA;
            Console.WriteLine(entobj.GROSS);
        }

        public decimal mCalcPF(EmpBEntity entobj)
        {

            entobj.PF = (entobj.BASIC) * (decimal)0.12;
            return _pf;

        }

        public decimal mCalcNet(EmpBEntity entobj)
        {

            _net = _gross - _pf;
            return _net;
        }



        #endregion

        #region Constructor
        #endregion





        public decimal _pf { get; set; }

        public decimal _net { get; set; }

        public decimal _gross { get; set; }
    }
}
