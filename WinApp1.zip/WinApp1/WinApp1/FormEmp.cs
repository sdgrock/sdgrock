﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp1
{

    public partial class FormEmp : Form
    {
        string str;
        public FormEmp()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            str += "Name - " + textBox1.Text + "\n";
            str += "DOJ - " + dateTimePicker1.Text + "\n";
            str += "City - " + comboBox2.Text + "\n";
            str += "Mobile - " + maskedTextBox1.Text + "\n";
            str += "Skills - ";
            foreach (string itm in listBox1.SelectedItems)
            {
                str += itm + " ";
            }
            str += "\n";
            str += "Experience - ";
            str += Convert.ToString(numericUpDown1.Value) + "\n";
            str += "\n";
            str += "Languages - ";
            foreach (Object o in groupBox2.Controls)
            {
                if (o is CheckBox)
                    if (((CheckBox)o).Checked == true)
                        str += ((CheckBox)o).Text + " ";
            }
            str += "\n";
            str += "Gender - ";
            if (radioButton1.Checked == true)
                str += radioButton1.Text;
            else
                str += radioButton2.Text;
            MessageBox.Show(str);
            richTextBox1.Text = str;
            richTextBox1.SaveFile(@"d:\test\emp1.txt", RichTextBoxStreamType.PlainText);
        }

    }
}
