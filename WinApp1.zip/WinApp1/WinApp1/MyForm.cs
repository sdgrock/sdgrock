﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp1
{
    public partial class MyForm : Form
    {
        int tht;
        int twd;
        Form frm;

        public MyForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = "Welcome Form";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = Image.FromFile(@"../../images/Desert.jpg");
                
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Opacity = 1;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tht = this.Height;
            twd = this.Width;
            this.Height = 600;
            this.Width = 600;
        }

        private void button8_Click(object sender, EventArgs e)
        {

            this.Height = tht;
            this.Width = twd;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //this.BackColor= color.LightCoral
            Color mycolor = Color.FromArgb(125, 200, 200);
            this.BackColor = mycolor;
        }
        
        //Show Form
        private void button9_Click(object sender, EventArgs e)
        {
            frm = new Form2();
            frm.StartPosition = FormStartPosition.Manual;
            frm.Location = new Point(350, 300);
            frm.Show();
            /*DialogResult res = frm.ShowDialog();

            if (res == DialogResult.OK)
            {
                MessageBox.Show(frm.Controls["textBox1"].Text);
            }
            else
                MessageBox.Show("Dialog cancelled");*/
        }

        //Hide form
        private void button10_Click(object sender, EventArgs e)
        {
            frm.Hide();
        }
    }
}
