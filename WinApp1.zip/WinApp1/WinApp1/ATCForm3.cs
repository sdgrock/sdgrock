﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp1
{
    public partial class ATCForm3 : Form
    {
        static int counter = 0;

        public ATCForm3()
        {
            InitializeComponent();
            //label1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //label1.Text += counter++;
            pictureBox1.Image = imageList1.Images[counter++%8];
        }

        private void ATCForm3_Load(object sender, EventArgs e)
        {

        }
    }
}
