﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyFirstAsp
{
    public partial class ASPday1p1 : System.Web.UI.Page
    {
        List<Gst> gstList = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = "Label on load";
            if(!Page.IsPostBack)
            {
                //Label1.Text = "Before going to Server";
                gstList = new List<Gst>
                {
                    new Gst { SlabName = "Food Items", TaxRate = 5 },
                    new Gst { SlabName = "Electronics Items", TaxRate = 12 },
                    new Gst { SlabName = "Automobiles Items", TaxRate = 18 }
                };
                DropDownList1.Items.Clear();
                DropDownList1.Items.Add(new ListItem("Select a Slab", "0"));
                DropDownList1.AppendDataBoundItems = true;
                DropDownList1.DataSource = gstList;
                DropDownList1.DataTextField = "Slabname";
                DropDownList1.DataValueField = "TaxRate";
                DropDownList1.DataBind();
            }
                    
         }
            //else
            //{
            //     Label1.Text = "Info from Server";
            //}
        }
}
       

        //protected void btnsubmit_Click(object sender, EventArgs e)
        //{
        //    //Label1.Text = "Welcome to ASP.NET";
        //}

        //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    //Label1.Text = DropDownList1.Text + " - "
        //    // + DropDownList1.SelectedItem ;   
        //    Label1.Text = DropDownList1.SelectedItem.Value + " - " + DropDownList1.SelectedItem.Text;                       
        //}
    //}
//}