﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class CEntity
    {

        #region Fields
        string Location;
        int training_id;
        string skills;
        int days;
        DateTime startDate;
        DateTime endDate;
        #endregion
        #region methods
#endregion

        #region property
        public string LOCATION { get { return Location; } set { Location = value; } }
        public int TRAININGID { get { return training_id; } set { training_id = value; } }
        public string SKILLS { get { return skills; } set { skills = value; } }
        public int DAYS { get { return days; } set { days = value; } }
        public DateTime STARTDATE { get { return startDate; } set { startDate = value; } }
        public DateTime ENDDATE { get { return endDate; } set { endDate = value; } }
        #endregion

        #region Constructor

        #endregion





    }
}
