﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace ConsoleApplication1
{
    class CBAL
    {
        public bool validate(Customer cobj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

        }



    }
}
