﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Person
    {
        #region Field
        string name;
        int age;
        int salary;
        #endregion

        #region Property
        public string NAME { get { return name; } set { name = value; } }
        public int AGE { get { return age; } set { age = value; } }
        public int SALARY { get { return salary; } set { salary = value; } }
        #endregion

        static void Main(string[] args)
        {
        }
    }
}
