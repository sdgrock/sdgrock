﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace shape
{
    /// <summary>
    /// Interaction logic for RoutedEvents.xaml
    /// </summary>
    public partial class RoutedEvents : Window
    {
        string Text;
        public RoutedEvents()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Text += "--Button is Clicked";
            txt1.Text = Text;
        }

        private void StackPanel_Click_1(object sender, RoutedEventArgs e)
        {
            Text += "--Click bubblled from Stack Panel";
            txt1.Text = Text;
        }

        private void Window_Click(object sender, RoutedEventArgs e)
        {
            Text += "--Click bubbled to window";
            txt1.Text = Text;
        }

        private void Button_PreviewClick(object sender, MouseButtonEventArgs e)
        {

            Text += "--Button is clicked";
            txt1.Text = Text;
        }


        private void StackPanel_PreviewClick(object sender, MouseButtonEventArgs e)
        {

            Text += "--Click tunneled from stack panel";
            txt1.Text = Text;
        }

        private void Window_PreviewClick(object sender, MouseButtonEventArgs e)
        {

            Text += "--Click tunneled from Window";
            txt1.Text = Text;
        }
    }
}
