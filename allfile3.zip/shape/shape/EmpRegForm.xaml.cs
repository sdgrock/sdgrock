﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace shape
{
    /// <summary>
    /// Interaction logic for EmpRegForm.xaml
    /// </summary>
    public partial class EmpRegForm : Window
    {
        public EmpRegForm()
        {
            
            InitializeComponent();

            
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = comboBox.SelectedIndex;


            if (index == 0)
            {
                return;
            }

            string state = ((ListBoxItem)comboBox.SelectedItem).Content.ToString();

            comboBox1.Items.Clear();
            comboBox1.Items.Add("Select a City");


            if (state == "Maharashtra")
            {
                comboBox1.Items.Add("Mumbai");
                comboBox1.Items.Add("Pune");
                comboBox1.Items.Add("Nasik");
            }

            else if (state == "WestBengal")
            {
                comboBox1.Items.Add("Kolkata");
                comboBox1.Items.Add("Darjeeling");
                comboBox1.Items.Add("Sodepur");
            }

            else if (state == "Karnataka")
            {
                comboBox1.Items.Add("Bangalore");
                comboBox1.Items.Add("Mysore");
                comboBox1.Items.Add("Udupi");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            StringBuilder data = new StringBuilder();
            data.Append(textBox.Text + "\n");
            DateTime dt = (DateTime)datePick.SelectedDate;
            data.Append(dt.ToShortDateString() + "\n");

            if (radioButton1.IsChecked == true)
                data.Append("Male" + "\n");
            else
                data.Append("Female" + "\n");

            if (checkSkill1.IsChecked == true)
                data.Append("C ");
            if (checkSkill2.IsChecked == true)
                data.Append("C++ ");
            if (checkSkill3.IsChecked == true)
                data.Append("C# ");
            data.Append("\n");

            data.Append(comboBox1.Text + "(" + comboBox.Text + ")");
            MessageBox.Show(data.ToString());

        }
    }
}
