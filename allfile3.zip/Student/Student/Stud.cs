﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public class Stud
    {
        public int StudentID;
        private string StudentName;
        private int Standard;
        private string Gender;
        
        public Stud(int StudentID,string StudentName,int Standard,string Gender)
        {
            this.StudentID=StudentID;
            this.StudentName=StudentName;;
            this.Standard=Standard;
            this.Gender = Gender;
        }
          
        
        public int ID
        {
            get { return StudentID;  }
            set { StudentID = value; }
        }

        public string Name
        {
            get { return StudentName ; }
            set { StudentName = value; }
        }
   
        public int STD
        {
            get { return Standard ; }
            set { Standard = value; }
        }
    
        public string Gen
        {
            get { return Gender ; }
            set { Gender = value; }
        }
    }
    class Student
    {
        static void Main(string[] args)
        {
            Stud obj;
            obj.StudentID = 101;
        }
    }
}
